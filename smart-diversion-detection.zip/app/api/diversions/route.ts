import { NextRequest, NextResponse } from 'next/server'
import { getAllDiversions, addDiversion, getDiversionsNearby } from '@/lib/mock-db'
import { Diversion } from '@/lib/types'

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const lat = searchParams.get('lat')
    const lon = searchParams.get('lon')
    const radius = searchParams.get('radius')

    // If location params provided, get nearby diversions
    if (lat && lon) {
      const latitude = parseFloat(lat)
      const longitude = parseFloat(lon)
      const searchRadius = radius ? parseFloat(radius) : 5

      if (isNaN(latitude) || isNaN(longitude)) {
        return NextResponse.json(
          { error: 'Invalid latitude or longitude' },
          { status: 400 }
        )
      }

      const nearbyDiversions = getDiversionsNearby(latitude, longitude, searchRadius)
      return NextResponse.json(nearbyDiversions)
    }

    // Otherwise return all diversions
    const allDiversions = getAllDiversions()
    return NextResponse.json(allDiversions)
  } catch (error) {
    console.error('Error fetching diversions:', error)
    return NextResponse.json(
      { error: 'Failed to fetch diversions' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Validate required fields
    if (
      !body.title ||
      !body.reason ||
      !body.location ||
      !body.location.latitude ||
      !body.location.longitude ||
      !body.severity ||
      !body.createdBy
    ) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    const newDiversion: Diversion = {
      id: Date.now().toString(),
      title: body.title,
      reason: body.reason,
      description: body.description || '',
      location: body.location,
      radius: body.radius || 5,
      alternativeRoute: body.alternativeRoute,
      severity: body.severity,
      startTime: body.startTime || new Date().toISOString(),
      endTime: body.endTime,
      createdBy: body.createdBy,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    const created = addDiversion(newDiversion)
    return NextResponse.json(created, { status: 201 })
  } catch (error) {
    console.error('Error creating diversion:', error)
    return NextResponse.json(
      { error: 'Failed to create diversion' },
      { status: 500 }
    )
  }
}
