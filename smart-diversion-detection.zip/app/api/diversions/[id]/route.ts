import { NextRequest, NextResponse } from 'next/server'
import { getDiversionById, updateDiversion, deleteDiversion } from '@/lib/mock-db'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params
    const diversion = getDiversionById(id)

    if (!diversion) {
      return NextResponse.json(
        { error: 'Diversion not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(diversion)
  } catch (error) {
    console.error('Error fetching diversion:', error)
    return NextResponse.json(
      { error: 'Failed to fetch diversion' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params
    const body = await request.json()

    const updated = updateDiversion(id, body)

    if (!updated) {
      return NextResponse.json(
        { error: 'Diversion not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(updated)
  } catch (error) {
    console.error('Error updating diversion:', error)
    return NextResponse.json(
      { error: 'Failed to update diversion' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params
    const deleted = deleteDiversion(id)

    if (!deleted) {
      return NextResponse.json(
        { error: 'Diversion not found' },
        { status: 404 }
      )
    }

    return NextResponse.json({ success: true, message: 'Diversion deleted' })
  } catch (error) {
    console.error('Error deleting diversion:', error)
    return NextResponse.json(
      { error: 'Failed to delete diversion' },
      { status: 500 }
    )
  }
}
