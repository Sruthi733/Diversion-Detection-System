'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import {
  AlertTriangle,
  MapPin,
  Bell,
  Navigation,
  BarChart3,
  ArrowRight,
} from 'lucide-react'
import Link from 'next/link'

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Navigation */}
      <nav className="border-b border-gray-200 bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-6 w-6 text-orange-600" />
            <span className="text-lg font-bold text-gray-900">Smart Diversion</span>
          </div>
          <div className="flex gap-3">
            <Link href="/admin">
              <Button variant="outline">Admin Dashboard</Button>
            </Link>
            <Link href="/user">
              <Button className="bg-indigo-600 hover:bg-indigo-700">User App</Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center space-y-8">
          <div className="space-y-4">
            <h1 className="text-5xl font-bold tracking-tight text-gray-900 sm:text-6xl">
              Smart Traffic
              <span className="block text-indigo-600">Diversion Detection</span>
            </h1>
            <p className="mx-auto max-w-2xl text-xl text-gray-600">
              Get real-time alerts about traffic diversions caused by road works, natural disasters, or political events. Navigate smarter with intelligent route suggestions.
            </p>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row justify-center">
            <Link href="/user">
              <Button size="lg" className="bg-indigo-600 hover:bg-indigo-700">
                Start Tracking
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/admin">
              <Button size="lg" variant="outline">
                Manage Diversions
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-20 space-y-12">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">Key Features</h2>
          <p className="mt-4 text-gray-600">Everything you need to manage traffic diversions efficiently</p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {/* Feature 1 */}
          <Card className="border-2 hover:border-indigo-200 hover:shadow-lg transition-all">
            <CardHeader>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-blue-100 mb-4">
                <MapPin className="h-6 w-6 text-blue-600" />
              </div>
              <CardTitle>Real-time Location Tracking</CardTitle>
              <CardDescription>
                Continuous GPS tracking to detect nearby diversions within 5km radius
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Your location is only used locally to find nearby traffic alerts. No data is stored.
              </p>
            </CardContent>
          </Card>

          {/* Feature 2 */}
          <Card className="border-2 hover:border-indigo-200 hover:shadow-lg transition-all">
            <CardHeader>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-orange-100 mb-4">
                <Bell className="h-6 w-6 text-orange-600" />
              </div>
              <CardTitle>Smart Notifications</CardTitle>
              <CardDescription>
                Get instant browser notifications, sound alerts, and vibrations when diversions are detected
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Customizable alert intensity based on diversion severity and distance.
              </p>
            </CardContent>
          </Card>

          {/* Feature 3 */}
          <Card className="border-2 hover:border-indigo-200 hover:shadow-lg transition-all">
            <CardHeader>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-green-100 mb-4">
                <Navigation className="h-6 w-6 text-green-600" />
              </div>
              <CardTitle>Google Maps Integration</CardTitle>
              <CardDescription>
                Get alternative route suggestions directly integrated with Google Maps
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                View routes on interactive maps and get turn-by-turn directions.
              </p>
            </CardContent>
          </Card>

          {/* Feature 4 */}
          <Card className="border-2 hover:border-indigo-200 hover:shadow-lg transition-all">
            <CardHeader>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-purple-100 mb-4">
                <BarChart3 className="h-6 w-6 text-purple-600" />
              </div>
              <CardTitle>Admin Dashboard</CardTitle>
              <CardDescription>
                Easy-to-use dashboard for traffic authorities to create and manage diversions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Add diversions with location, reason, severity, and alternative routes.
              </p>
            </CardContent>
          </Card>

          {/* Feature 5 */}
          <Card className="border-2 hover:border-indigo-200 hover:shadow-lg transition-all">
            <CardHeader>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-red-100 mb-4">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
              <CardTitle>Multiple Diversion Types</CardTitle>
              <CardDescription>
                Support for road works, tree fallen, flooding, political issues, and more
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Severity levels (low, medium, high) help users prioritize alternative routes.
              </p>
            </CardContent>
          </Card>

          {/* Feature 6 */}
          <Card className="border-2 hover:border-indigo-200 hover:shadow-lg transition-all">
            <CardHeader>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-indigo-100 mb-4">
                <MapPin className="h-6 w-6 text-indigo-600" />
              </div>
              <CardTitle>5km Alert Radius</CardTitle>
              <CardDescription>
                Users within 5km of a diversion are automatically notified
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Customizable radius per diversion for flexible coverage.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Diversions Types Section */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-20 space-y-12 bg-gray-50 rounded-2xl p-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900">Supported Diversion Types</h2>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[
            { name: 'Road Works', emoji: '🏗️' },
            { name: 'Tree Fallen', emoji: '🌳' },
            { name: 'Flooding', emoji: '🌊' },
            { name: 'Political Issues', emoji: '🚨' },
            { name: 'Accidents', emoji: '⚠️' },
            { name: 'Other', emoji: '📍' },
          ].map((type) => (
            <div
              key={type.name}
              className="flex items-center gap-3 rounded-lg bg-white border border-gray-200 p-4 hover:border-indigo-300 transition-colors"
            >
              <span className="text-2xl">{type.emoji}</span>
              <span className="font-medium text-gray-900">{type.name}</span>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-20 space-y-8">
        <div className="rounded-2xl bg-gradient-to-r from-indigo-600 to-blue-600 p-12 text-center text-white">
          <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Join our smart traffic system and never get stuck in an unexpected diversion again.
          </p>
          <div className="flex flex-col gap-3 sm:flex-row justify-center">
            <Link href="/user">
              <Button
                size="lg"
                className="bg-white text-indigo-600 hover:bg-gray-100"
              >
                Start as User
              </Button>
            </Link>
            <Link href="/admin">
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white/10 bg-transparent"
              >
                Access Admin Panel
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-200 bg-gray-50">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex flex-col gap-6 sm:flex-row justify-between items-center">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-orange-600" />
              <span className="font-semibold text-gray-900">Smart Diversion</span>
            </div>
            <p className="text-sm text-gray-600 text-center sm:text-right">
              Making your commute smarter and safer
            </p>
          </div>
        </div>
      </footer>
    </main>
  )
}
