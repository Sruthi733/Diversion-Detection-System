'use client'

import { useState, useEffect } from 'react'
import { useLocationTracking } from '@/hooks/use-location-tracking'
import { NotificationToast } from '@/components/user/notification-toast'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { MapPin, AlertTriangle, Navigation, Loader } from 'lucide-react'
import { Diversion } from '@/lib/types'

export default function UserPage() {
  const {
    location,
    nearbyDiversions,
    notifications,
    notificationsEnabled,
    startTracking,
    stopTracking,
    requestNotificationPermission,
    clearNotification,
  } = useLocationTracking(5000)
  const [hasStarted, setHasStarted] = useState(false)
  const [permissionRequested, setPermissionRequested] = useState(false)

  const handleStartTracking = async () => {
    // Request notification permission if not already requested
    if (!notificationsEnabled && !permissionRequested) {
      const granted = await requestNotificationPermission()
      setPermissionRequested(true)
      if (!granted) {
        console.warn('Notifications not granted - will use in-app notifications only')
      }
    }
    startTracking()
    setHasStarted(true)
  }

  const handleStopTracking = () => {
    stopTracking()
    setHasStarted(false)
  }

  const handleEnableNotifications = async () => {
    const granted = await requestNotificationPermission()
    setPermissionRequested(true)
    if (!granted) {
      alert('Please enable notifications in your browser settings to receive alerts.')
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low':
        return 'bg-blue-50 border-blue-200'
      case 'medium':
        return 'bg-yellow-50 border-yellow-200'
      case 'high':
        return 'bg-red-50 border-red-200'
      default:
        return 'bg-gray-50 border-gray-200'
    }
  }

  const getSeverityBadgeColor = (severity: string) => {
    switch (severity) {
      case 'low':
        return 'bg-blue-100 text-blue-800'
      case 'medium':
        return 'bg-yellow-100 text-yellow-800'
      case 'high':
        return 'bg-red-100 text-red-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4 sm:p-8">
      <div className="mx-auto max-w-4xl">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-gray-900">Smart Diversion Tracker</h1>
          <p className="mt-2 text-gray-600">Get real-time alerts about traffic diversions near you</p>
        </div>

        {/* Location Status Card */}
        <Card className="mb-6 border-2 border-indigo-200">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Navigation className="h-5 w-5" />
              Location Tracking
            </CardTitle>
            <CardDescription>
              {location.isTracking ? 'Currently tracking your location' : 'Enable location tracking to get alerts'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Location Info */}
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="rounded-lg bg-gray-50 p-3">
                <p className="text-xs text-gray-600 uppercase">Latitude</p>
                <p className="mt-1 font-mono text-sm font-semibold text-gray-900">
                  {location.latitude ? location.latitude.toFixed(4) : 'N/A'}
                </p>
              </div>
              <div className="rounded-lg bg-gray-50 p-3">
                <p className="text-xs text-gray-600 uppercase">Longitude</p>
                <p className="mt-1 font-mono text-sm font-semibold text-gray-900">
                  {location.longitude ? location.longitude.toFixed(4) : 'N/A'}
                </p>
              </div>
              <div className="rounded-lg bg-gray-50 p-3">
                <p className="text-xs text-gray-600 uppercase">Accuracy</p>
                <p className="mt-1 font-mono text-sm font-semibold text-gray-900">
                  {location.accuracy ? `${location.accuracy.toFixed(0)}m` : 'N/A'}
                </p>
              </div>
            </div>

            {/* Notification Status */}
            {!notificationsEnabled && permissionRequested && (
              <div className="rounded-lg bg-yellow-50 border border-yellow-200 p-3">
                <p className="text-xs text-yellow-800">
                  <strong>Notifications:</strong> Browser notifications disabled. You'll receive in-app alerts only.
                </p>
              </div>
            )}

            {/* Error Message */}
            {location.error && (
              <div className="rounded-lg bg-red-50 border border-red-200 p-3">
                <p className="text-xs text-red-800">
                  <strong>Error:</strong> {location.error}
                </p>
              </div>
            )}

            {/* Control Buttons */}
            <div className="space-y-2">
              <div className="flex gap-2">
                <Button
                  onClick={handleStartTracking}
                  disabled={location.isTracking}
                  className="flex-1 bg-indigo-600 hover:bg-indigo-700"
                >
                  {location.isTracking ? (
                    <>
                      <Loader className="mr-2 h-4 w-4 animate-spin" />
                      Tracking Active
                    </>
                  ) : (
                    'Start Tracking'
                  )}
                </Button>
                <Button
                  onClick={handleStopTracking}
                  disabled={!location.isTracking}
                  variant="outline"
                  className="flex-1 bg-transparent"
                >
                  Stop Tracking
                </Button>
              </div>
              {!notificationsEnabled && (
                <Button
                  onClick={handleEnableNotifications}
                  variant="outline"
                  className="w-full border-blue-300 text-blue-600 hover:bg-blue-50 bg-transparent"
                >
                  Enable Browser Notifications
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Nearby Diversions */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Nearby Diversions
            </CardTitle>
            <CardDescription>
              {nearbyDiversions.length === 0
                ? 'No diversions near you'
                : `${nearbyDiversions.length} diversion(s) within 5km`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {nearbyDiversions.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <MapPin className="mb-3 h-12 w-12 text-gray-300" />
                <p className="text-sm text-gray-600">No traffic diversions detected nearby</p>
              </div>
            ) : (
              <div className="space-y-3">
                {nearbyDiversions.map((diversion: Diversion) => (
                  <div
                    key={diversion.id}
                    className={`rounded-lg border-2 p-4 transition-colors ${getSeverityColor(
                      diversion.severity
                    )}`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold text-gray-900">{diversion.title}</h3>
                          <Badge className={getSeverityBadgeColor(diversion.severity)}>
                            {diversion.severity.toUpperCase()}
                          </Badge>
                        </div>
                        <p className="mt-1 text-sm text-gray-700">{diversion.description}</p>

                        {diversion.alternativeRoute && (
                          <div className="mt-2 rounded bg-white/50 px-3 py-2 text-sm text-gray-700">
                            <strong>Alternative Route:</strong> {diversion.alternativeRoute}
                          </div>
                        )}

                        <div className="mt-2 text-xs text-gray-600 space-y-1">
                          <p>
                            <strong>Location:</strong> {diversion.location.latitude.toFixed(4)},{' '}
                            {diversion.location.longitude.toFixed(4)}
                          </p>
                          <p>
                            <strong>Reason:</strong> {diversion.reason.replace('_', ' ')}
                          </p>
                          <p>
                            <strong>Radius:</strong> {diversion.radius} km
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Notifications Container */}
        <div className="fixed bottom-4 right-4 left-4 sm:left-auto space-y-3 pointer-events-none max-w-sm">
          {notifications.map((notification) => (
            <NotificationToast
              key={notification.diversionId}
              notification={notification}
              onClose={() => clearNotification(notification.diversionId)}
            />
          ))}
        </div>
      </div>
    </main>
  )
}
