'use client'

import { useEffect, useState } from 'react'
import { AddDiversionForm } from '@/components/admin/add-diversion-form'
import { DiversionsList } from '@/components/admin/diversions-list'
import { Diversion } from '@/lib/types'
import { AlertCircle } from 'lucide-react'

export default function AdminPage() {
  const [diversions, setDiversions] = useState<Diversion[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')

  // Fetch diversions on mount
  useEffect(() => {
    fetchDiversions()
  }, [])

  const fetchDiversions = async () => {
    try {
      const response = await fetch('/api/diversions')
      if (!response.ok) throw new Error('Failed to fetch diversions')
      const data = await response.json()
      setDiversions(data)
    } catch (err) {
      console.error('Error fetching diversions:', err)
      setError('Failed to load diversions')
    }
  }

  const handleAddDiversion = async (
    diversion: Omit<Diversion, 'id' | 'createdAt' | 'updatedAt'>
  ) => {
    setIsLoading(true)
    try {
      const response = await fetch('/api/diversions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(diversion),
      })

      if (!response.ok) throw new Error('Failed to create diversion')

      const newDiversion = await response.json()
      setDiversions((prev) => [...prev, newDiversion])
      setError('')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create diversion')
    } finally {
      setIsLoading(false)
    }
  }

  const handleDeleteDiversion = async (id: string) => {
    setIsLoading(true)
    try {
      const response = await fetch(`/api/diversions/${id}`, { method: 'DELETE' })
      if (!response.ok) throw new Error('Failed to delete diversion')

      setDiversions((prev) => prev.filter((d) => d.id !== id))
      setError('')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete diversion')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gray-50 p-4 sm:p-8">
      <div className="mx-auto max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Smart Diversion Management</h1>
          <p className="mt-2 text-gray-600">Create and manage traffic diversions for your city</p>
        </div>

        {/* Global Error */}
        {error && (
          <div className="mb-6 rounded-lg bg-red-50 border border-red-200 p-4 flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-red-600 mt-0.5 flex-shrink-0" />
            <p className="text-sm text-red-800">{error}</p>
          </div>
        )}

        {/* Grid Layout */}
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Form Section */}
          <div className="lg:col-span-1">
            <AddDiversionForm onSubmit={handleAddDiversion} isLoading={isLoading} />
          </div>

          {/* Diversions List Section */}
          <div className="lg:col-span-2">
            <DiversionsList
              diversions={diversions}
              onDelete={handleDeleteDiversion}
              isLoading={isLoading}
            />
          </div>
        </div>
      </div>
    </main>
  )
}
