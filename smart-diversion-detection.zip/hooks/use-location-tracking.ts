'use client';

import { useEffect, useState, useRef, useCallback } from 'react'
import { Diversion, NotificationData } from '@/lib/types'
import { calculateDistance } from '@/lib/mock-db'
import { notificationService } from '@/lib/notification-service'

interface LocationState {
  latitude: number | null
  longitude: number | null
  accuracy: number | null
  error: string | null
  isTracking: boolean
}

export function useLocationTracking(checkIntervalMs = 5000) {
  const [location, setLocation] = useState<LocationState>({
    latitude: null,
    longitude: null,
    accuracy: null,
    error: null,
    isTracking: false,
  })

  const [nearbyDiversions, setNearbyDiversions] = useState<Diversion[]>([])
  const [notifications, setNotifications] = useState<NotificationData[]>([])
  const [notificationsEnabled, setNotificationsEnabled] = useState(false)
  const watchIdRef = useRef<number | null>(null)
  const lastFetchRef = useRef<number>(0)
  const shownNotificationsRef = useRef<Set<string>>(new Set())

  // Request notification permissions
  const requestNotificationPermission = useCallback(async () => {
    try {
      const granted = await notificationService.requestPermission()
      setNotificationsEnabled(granted)
      return granted
    } catch (error) {
      console.error('Error requesting notification permission:', error)
      return false
    }
  }, [])

  // Start tracking location
  const startTracking = useCallback(() => {
    if (!navigator.geolocation) {
      setLocation((prev) => ({
        ...prev,
        error: 'Geolocation not supported by your browser',
      }))
      return
    }

    setLocation((prev) => ({ ...prev, isTracking: true, error: null }))

    // Initial position
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude, accuracy } = position.coords
        setLocation({
          latitude,
          longitude,
          accuracy,
          error: null,
          isTracking: true,
        })
        checkNearbyDiversions(latitude, longitude)
      },
      (error) => {
        setLocation((prev) => ({
          ...prev,
          error: error.message,
          isTracking: false,
        }))
      },
      { enableHighAccuracy: true, maximumAge: 0 }
    )

    // Watch position for continuous updates
    watchIdRef.current = navigator.geolocation.watchPosition(
      (position) => {
        const { latitude, longitude, accuracy } = position.coords
        setLocation({
          latitude,
          longitude,
          accuracy,
          error: null,
          isTracking: true,
        })
        checkNearbyDiversions(latitude, longitude)
      },
      (error) => {
        console.error('Location tracking error:', error)
      },
      { enableHighAccuracy: true, maximumAge: 0, timeout: 10000 }
    )
  }, [])

  // Stop tracking location
  const stopTracking = useCallback(() => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current)
      watchIdRef.current = null
    }
    setLocation((prev) => ({ ...prev, isTracking: false }))
    setNearbyDiversions([])
    setNotifications([])
  }, [])

  // Check for nearby diversions
  const checkNearbyDiversions = useCallback(
    async (latitude: number, longitude: number) => {
      const now = Date.now()
      // Throttle API calls
      if (now - lastFetchRef.current < checkIntervalMs) {
        return
      }
      lastFetchRef.current = now

      try {
        const response = await fetch(
          `/api/diversions?lat=${latitude}&lon=${longitude}&radius=5`
        )
        if (!response.ok) throw new Error('Failed to fetch nearby diversions')

        const diversions: Diversion[] = await response.json()
        setNearbyDiversions(diversions)

        // Generate notifications for newly discovered diversions
        const newNotifications: NotificationData[] = diversions.map((div) => {
          const distance = calculateDistance(latitude, longitude, div.location.latitude, div.location.longitude)
          return {
            diversionId: div.id,
            title: `Diversion Alert: ${div.title}`,
            message: `There's a ${div.reason.replace('_', ' ')} ${distance.toFixed(1)}km away. ${div.description}`,
            alternativeRoute: div.alternativeRoute,
            distance,
          }
        })

        setNotifications(newNotifications)

        // Send browser notifications for new diversions
        if (notificationsEnabled) {
          newNotifications.forEach((notif) => {
            if (!shownNotificationsRef.current.has(notif.diversionId)) {
              notificationService.sendAlert(notif, true, true)
              shownNotificationsRef.current.add(notif.diversionId)
            }
          })
        }
      } catch (error) {
        console.error('Error checking nearby diversions:', error)
      }
    },
    [checkIntervalMs]
  )

  // Clear notifications
  const clearNotifications = useCallback(() => {
    setNotifications([])
  }, [])

  // Clear a specific notification
  const clearNotification = useCallback((diversionId: string) => {
    setNotifications((prev) => prev.filter((n) => n.diversionId !== diversionId))
  }, [])

  useEffect(() => {
    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current)
      }
    }
  }, [])

  return {
    location,
    nearbyDiversions,
    notifications,
    notificationsEnabled,
    startTracking,
    stopTracking,
    requestNotificationPermission,
    clearNotifications,
    clearNotification,
  }
}
