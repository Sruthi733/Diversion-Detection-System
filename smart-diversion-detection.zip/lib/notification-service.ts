import { NotificationData } from './types'

/**
 * Notification Service - Handles browser notifications and sound alerts
 */

export class NotificationService {
  private static instance: NotificationService

  private constructor() {}

  static getInstance(): NotificationService {
    if (!NotificationService.instance) {
      NotificationService.instance = new NotificationService()
    }
    return NotificationService.instance
  }

  /**
   * Request notification permissions from user
   */
  async requestPermission(): Promise<boolean> {
    if (!('Notification' in window)) {
      console.warn('Notifications not supported by this browser')
      return false
    }

    if (Notification.permission === 'granted') {
      return true
    }

    if (Notification.permission !== 'denied') {
      try {
        const permission = await Notification.requestPermission()
        return permission === 'granted'
      } catch (error) {
        console.error('Error requesting notification permission:', error)
        return false
      }
    }

    return false
  }

  /**
   * Check if notifications are enabled
   */
  isEnabled(): boolean {
    return 'Notification' in window && Notification.permission === 'granted'
  }

  /**
   * Send a browser notification
   */
  sendNotification(notification: NotificationData): void {
    if (!this.isEnabled()) {
      return
    }

    const options: NotificationOptions = {
      body: notification.message,
      icon: '/icon.png',
      badge: '/badge.png',
      tag: notification.diversionId, // Prevents duplicate notifications
      requireInteraction: true, // Keep notification visible until user interacts
      actions: notification.alternativeRoute
        ? [
            {
              action: 'open-map',
              title: 'View Route',
              icon: '/icons/map.png',
            },
            {
              action: 'dismiss',
              title: 'Dismiss',
              icon: '/icons/close.png',
            },
          ]
        : [
            {
              action: 'dismiss',
              title: 'Dismiss',
              icon: '/icons/close.png',
            },
          ],
    }

    try {
      const notif = new Notification(notification.title, options)

      notif.onclick = () => {
        window.focus()
        notif.close()
      }

      notif.onclose = () => {
        console.log('Notification closed')
      }
    } catch (error) {
      console.error('Error sending notification:', error)
    }
  }

  /**
   * Play a sound alert
   */
  playAlert(type: 'low' | 'medium' | 'high' = 'medium'): void {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()
    const oscillator = audioContext.createOscillator()
    const gainNode = audioContext.createGain()

    oscillator.connect(gainNode)
    gainNode.connect(audioContext.destination)

    // Different frequencies for different severity levels
    const frequencies = {
      low: 440, // A4
      medium: 660, // E5
      high: 880, // A5
    }

    oscillator.frequency.value = frequencies[type]
    oscillator.type = 'sine'

    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime)
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5)

    oscillator.start(audioContext.currentTime)
    oscillator.stop(audioContext.currentTime + 0.5)
  }

  /**
   * Show vibration pattern
   */
  vibrate(pattern: number | number[] = [200, 100, 200]): void {
    if ('vibrate' in navigator) {
      navigator.vibrate(pattern)
    }
  }

  /**
   * Send a comprehensive alert (notification + sound + vibration)
   */
  sendAlert(notification: NotificationData, playSoundAlert = true, vibrate = true): void {
    this.sendNotification(notification)

    if (playSoundAlert) {
      this.playAlert(notification.distance > 3 ? 'low' : notification.distance > 1 ? 'medium' : 'high')
    }

    if (vibrate) {
      const pattern = notification.distance > 3 ? [100, 50, 100] : notification.distance > 1 ? [200, 100, 200] : [300, 150, 300]
      this.vibrate(pattern)
    }
  }

  /**
   * Close a specific notification by tag
   */
  closeNotification(diversionId: string): void {
    // Note: Notification API doesn't provide a direct way to close notifications by tag
    // This would need to be handled through the service worker
    console.log(`Attempting to close notification for diversion: ${diversionId}`)
  }
}

export const notificationService = NotificationService.getInstance()
