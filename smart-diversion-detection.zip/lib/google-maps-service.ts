/**
 * Google Maps Service - Handles all Google Maps API interactions
 * Note: Requires NEXT_PUBLIC_GOOGLE_MAPS_API_KEY environment variable
 */

export interface RouteInfo {
  distance: string
  duration: string
  steps: RouteStep[]
  polyline?: string
}

export interface RouteStep {
  instruction: string
  distance: string
  duration: string
}

export interface Location {
  lat: number
  lng: number
}

export class GoogleMapsService {
  private static instance: GoogleMapsService
  private apiKey: string | null = null
  private mapsLoaded = false

  private constructor() {
    this.apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || null
  }

  static getInstance(): GoogleMapsService {
    if (!GoogleMapsService.instance) {
      GoogleMapsService.instance = new GoogleMapsService()
    }
    return GoogleMapsService.instance
  }

  /**
   * Load Google Maps API script
   */
  async loadMapsAPI(): Promise<void> {
    if (this.mapsLoaded || !this.apiKey) {
      return
    }

    return new Promise((resolve, reject) => {
      if (typeof window === 'undefined') {
        reject(new Error('Window is not defined'))
        return
      }

      if ((window as any).google?.maps) {
        this.mapsLoaded = true
        resolve()
        return
      }

      const script = document.createElement('script')
      script.src = `https://maps.googleapis.com/maps/api/js?key=${this.apiKey}&libraries=places,routes`
      script.async = true
      script.defer = true

      script.onload = () => {
        this.mapsLoaded = true
        resolve()
      }

      script.onerror = () => {
        reject(new Error('Failed to load Google Maps API'))
      }

      document.head.appendChild(script)
    })
  }

  /**
   * Get route between two locations
   */
  async getRoute(
    origin: Location | string,
    destination: Location | string
  ): Promise<RouteInfo | null> {
    if (!this.apiKey) {
      console.error('Google Maps API key not configured')
      return null
    }

    const originStr = typeof origin === 'string' ? origin : `${origin.lat},${origin.lng}`
    const destStr = typeof destination === 'string' ? destination : `${destination.lat},${destination.lng}`

    try {
      const response = await fetch(
        `/api/directions?origin=${encodeURIComponent(originStr)}&destination=${encodeURIComponent(
          destStr
        )}`
      )

      if (!response.ok) {
        throw new Error('Failed to fetch route')
      }

      const data = await response.json()
      return data as RouteInfo
    } catch (error) {
      console.error('Error getting route:', error)
      return null
    }
  }

  /**
   * Get multiple routes (for alternative route suggestions)
   */
  async getAlternativeRoutes(
    origin: Location | string,
    destination: Location | string,
    avoidAreas?: Location[]
  ): Promise<RouteInfo[]> {
    if (!this.apiKey) {
      console.error('Google Maps API key not configured')
      return []
    }

    // This would require multiple API calls or a custom backend
    // For now, return primary route only
    const primaryRoute = await this.getRoute(origin, destination)
    return primaryRoute ? [primaryRoute] : []
  }

  /**
   * Get distance matrix between multiple points
   */
  async getDistanceMatrix(
    origins: (Location | string)[],
    destinations: (Location | string)[]
  ): Promise<{ distance: string; duration: string }[][] | null> {
    if (!this.apiKey) {
      console.error('Google Maps API key not configured')
      return null
    }

    try {
      const originsStr = origins.map((o) => (typeof o === 'string' ? o : `${o.lat},${o.lng}`)).join('|')

      const destinationsStr = destinations
        .map((d) => (typeof d === 'string' ? d : `${d.lat},${d.lng}`))
        .join('|')

      const response = await fetch(
        `/api/distance-matrix?origins=${encodeURIComponent(originsStr)}&destinations=${encodeURIComponent(
          destinationsStr
        )}`
      )

      if (!response.ok) {
        throw new Error('Failed to fetch distance matrix')
      }

      const data = await response.json()
      return data as { distance: string; duration: string }[][]
    } catch (error) {
      console.error('Error getting distance matrix:', error)
      return null
    }
  }

  /**
   * Get place suggestions (autocomplete)
   */
  async getPlaceSuggestions(input: string): Promise<string[]> {
    if (!this.apiKey) {
      console.error('Google Maps API key not configured')
      return []
    }

    try {
      const response = await fetch(`/api/place-suggestions?input=${encodeURIComponent(input)}`)

      if (!response.ok) {
        throw new Error('Failed to fetch place suggestions')
      }

      const data = await response.json()
      return data.suggestions as string[]
    } catch (error) {
      console.error('Error getting place suggestions:', error)
      return []
    }
  }

  /**
   * Get coordinates from place name
   */
  async getCoordinatesFromPlace(place: string): Promise<Location | null> {
    if (!this.apiKey) {
      console.error('Google Maps API key not configured')
      return null
    }

    try {
      const response = await fetch(`/api/geocode?address=${encodeURIComponent(place)}`)

      if (!response.ok) {
        throw new Error('Failed to geocode place')
      }

      const data = await response.json()
      return data.location as Location
    } catch (error) {
      console.error('Error geocoding place:', error)
      return null
    }
  }

  /**
   * Estimate travel time with traffic
   */
  async getTravelTime(
    origin: Location | string,
    destination: Location | string,
    trafficModel: 'best_guess' | 'pessimistic' | 'optimistic' = 'best_guess'
  ): Promise<{ distance: string; duration: string; duration_in_traffic: string } | null> {
    if (!this.apiKey) {
      console.error('Google Maps API key not configured')
      return null
    }

    const originStr = typeof origin === 'string' ? origin : `${origin.lat},${origin.lng}`
    const destStr = typeof destination === 'string' ? destination : `${destination.lat},${destination.lng}`

    try {
      const response = await fetch(
        `/api/distance-matrix?origins=${encodeURIComponent(originStr)}&destinations=${encodeURIComponent(
          destStr
        )}&traffic_model=${trafficModel}`
      )

      if (!response.ok) {
        throw new Error('Failed to fetch travel time')
      }

      const data = await response.json()
      return data
    } catch (error) {
      console.error('Error getting travel time:', error)
      return null
    }
  }

  /**
   * Check if API key is configured
   */
  isConfigured(): boolean {
    return !!this.apiKey
  }

  /**
   * Check if Maps API is loaded
   */
  isLoaded(): boolean {
    return this.mapsLoaded
  }
}

export const googleMapsService = GoogleMapsService.getInstance()
