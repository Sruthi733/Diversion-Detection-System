export interface Location {
  latitude: number
  longitude: number
}

export interface Diversion {
  id: string
  title: string
  reason: 'roadworks' | 'tree_fallen' | 'flooding' | 'political' | 'other'
  description: string
  location: Location
  radius: number // in kilometers
  alternativeRoute?: string
  severity: 'low' | 'medium' | 'high'
  startTime: string // ISO 8601
  endTime?: string // ISO 8601
  createdBy: string
  createdAt: string
  updatedAt: string
}

export interface NotificationData {
  diversionId: string
  title: string
  message: string
  alternativeRoute?: string
  distance: number // in kilometers
}

export interface User {
  id: string
  email: string
  password: string // hashed
  role: 'admin' | 'user'
  createdAt: string
}
