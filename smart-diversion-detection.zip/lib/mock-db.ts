import { Diversion, User } from './types'

// Mock data storage - will be replaced with real database
export const mockDiversions: Diversion[] = [
  {
    id: '1',
    title: 'Road Works on Main Street',
    reason: 'roadworks',
    description: 'Construction work on Main Street for water pipeline installation',
    location: { latitude: 13.0827, longitude: 80.2707 }, // Chennai coordinates
    radius: 5,
    alternativeRoute: 'Use Broadway or Marina Street',
    severity: 'high',
    startTime: new Date().toISOString(),
    endTime: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
    createdBy: 'admin1',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
]

export const mockUsers: User[] = [
  {
    id: 'admin1',
    email: 'admin@smartdiversion.com',
    password: '$2b$10$YourHashedPasswordHere', // In real app, use bcrypt
    role: 'admin',
    createdAt: new Date().toISOString(),
  },
]

// Helper functions
export function getDiversionById(id: string): Diversion | undefined {
  return mockDiversions.find((d) => d.id === id)
}

export function getAllDiversions(): Diversion[] {
  return mockDiversions
}

export function getDiversionsNearby(
  latitude: number,
  longitude: number,
  radiusKm: number = 5
): Diversion[] {
  return mockDiversions.filter((diversion) => {
    const distance = calculateDistance(
      latitude,
      longitude,
      diversion.location.latitude,
      diversion.location.longitude
    )
    return distance <= radiusKm
  })
}

export function addDiversion(diversion: Diversion): Diversion {
  mockDiversions.push(diversion)
  return diversion
}

export function updateDiversion(id: string, updates: Partial<Diversion>): Diversion | null {
  const index = mockDiversions.findIndex((d) => d.id === id)
  if (index !== -1) {
    mockDiversions[index] = { ...mockDiversions[index], ...updates, updatedAt: new Date().toISOString() }
    return mockDiversions[index]
  }
  return null
}

export function deleteDiversion(id: string): boolean {
  const index = mockDiversions.findIndex((d) => d.id === id)
  if (index !== -1) {
    mockDiversions.splice(index, 1)
    return true
  }
  return false
}

export function getUserByEmail(email: string): User | undefined {
  return mockUsers.find((u) => u.email === email)
}

// Haversine formula to calculate distance between two coordinates
export function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371 // Earth's radius in kilometers
  const dLat = toRad(lat2 - lat1)
  const dLon = toRad(lon2 - lon1)
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return R * c
}

function toRad(value: number): number {
  return (value * Math.PI) / 180
}
