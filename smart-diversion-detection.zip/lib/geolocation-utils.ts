/**
 * Geolocation Utilities - Helper functions for location-based features
 */

export interface GeolocationCoordinates {
  latitude: number
  longitude: number
  accuracy?: number
  altitude?: number | null
  altitudeAccuracy?: number | null
  heading?: number | null
  speed?: number | null
}

/**
 * Request current user location
 */
export async function getCurrentLocation(): Promise<GeolocationCoordinates> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation not supported'))
      return
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude, accuracy, altitude, altitudeAccuracy, heading, speed } =
          position.coords
        resolve({
          latitude,
          longitude,
          accuracy,
          altitude,
          altitudeAccuracy,
          heading,
          speed,
        })
      },
      (error) => {
        let message = 'Unknown error'
        switch (error.code) {
          case error.PERMISSION_DENIED:
            message = 'Permission denied. Please enable location access in your browser settings.'
            break
          case error.POSITION_UNAVAILABLE:
            message = 'Position unavailable. Unable to retrieve location.'
            break
          case error.TIMEOUT:
            message = 'Location request timed out.'
            break
        }
        reject(new Error(message))
      },
      {
        enableHighAccuracy: true,
        maximumAge: 0,
        timeout: 10000,
      }
    );
  })
}

/**
 * Watch user location with continuous updates
 */
export function watchLocation(
  onSuccess: (coords: GeolocationCoordinates) => void,
  onError?: (error: Error) => void,
  options?: PositionOptions
): number | null {
  if (!navigator.geolocation) {
    onError?.(new Error('Geolocation not supported'))
    return null
  }

  return navigator.geolocation.watchPosition(
    (position) => {
      const { latitude, longitude, accuracy, altitude, altitudeAccuracy, heading, speed } =
        position.coords
      onSuccess({
        latitude,
        longitude,
        accuracy,
        altitude,
        altitudeAccuracy,
        heading,
        speed,
      })
    },
    (error) => {
      let message = 'Unknown error'
      switch (error.code) {
        case error.PERMISSION_DENIED:
          message = 'Permission denied. Please enable location access in your browser settings.'
          break
        case error.POSITION_UNAVAILABLE:
          message = 'Position unavailable. Unable to retrieve location.'
          break
        case error.TIMEOUT:
          message = 'Location request timed out.'
          break
      }
      onError?.(new Error(message))
    },
    options || {
      enableHighAccuracy: true,
      maximumAge: 0,
      timeout: 10000,
    }
  )
}

/**
 * Stop watching location
 */
export function stopWatchingLocation(watchId: number): void {
  if (navigator.geolocation && watchId !== null) {
    navigator.geolocation.clearWatch(watchId)
  }
}

/**
 * Check if location services are available
 */
export function isLocationServicesAvailable(): boolean {
  return 'geolocation' in navigator
}

/**
 * Check if location services are enabled (requires user interaction)
 */
export async function areLocationServicesEnabled(): Promise<boolean> {
  if (!isLocationServicesAvailable()) {
    return false
  }

  try {
    await getCurrentLocation()
    return true
  } catch {
    return false
  }
}

/**
 * Request high-accuracy location (uses GPS if available)
 */
export async function getHighAccuracyLocation(): Promise<GeolocationCoordinates> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation not supported'))
      return
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude, accuracy, altitude, altitudeAccuracy, heading, speed } =
          position.coords
        resolve({
          latitude,
          longitude,
          accuracy,
          altitude,
          altitudeAccuracy,
          heading,
          speed,
        })
      },
      (error) => {
        reject(new Error(`Location error: ${error.message}`))
      },
      {
        enableHighAccuracy: true,
        maximumAge: 0,
        timeout: 30000, // Give more time for high accuracy
      }
    )
  })
}

/**
 * Request low-accuracy location (faster, uses WiFi/cell triangulation)
 */
export async function getLowAccuracyLocation(): Promise<GeolocationCoordinates> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation not supported'))
      return
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude, accuracy, altitude, altitudeAccuracy, heading, speed } =
          position.coords
        resolve({
          latitude,
          longitude,
          accuracy,
          altitude,
          altitudeAccuracy,
          heading,
          speed,
        })
      },
      (error) => {
        reject(new Error(`Location error: ${error.message}`))
      },
      {
        enableHighAccuracy: false,
        maximumAge: 60000, // Use cached position if available
        timeout: 5000,
      }
    )
  })
}

/**
 * Reverse geocoding simulation (would integrate with Google Maps or other service)
 */
export async function getAddressFromCoordinates(
  latitude: number,
  longitude: number
): Promise<string> {
  // This is a placeholder - in production, use Google Maps Geocoding API or similar
  // For now, just return coordinates formatted as string
  return `${latitude.toFixed(4)}, ${longitude.toFixed(4)}`
}

/**
 * Get formatted address components
 */
export async function getAddressComponents(latitude: number, longitude: number) {
  try {
    const address = await getAddressFromCoordinates(latitude, longitude)
    return {
      fullAddress: address,
      city: 'Unknown',
      state: 'Unknown',
      country: 'Unknown',
      zip: 'Unknown',
    }
  } catch (error) {
    throw new Error(`Failed to get address: ${error instanceof Error ? error.message : 'Unknown error'}`)
  }
}
