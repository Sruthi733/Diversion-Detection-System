'use client'

import React from "react"

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Diversion } from '@/lib/types'

interface AddDiversionFormProps {
  onSubmit: (diversion: Omit<Diversion, 'id' | 'createdAt' | 'updatedAt'>) => Promise<void>
  isLoading?: boolean
}

export function AddDiversionForm({ onSubmit, isLoading = false }: AddDiversionFormProps) {
  const [formData, setFormData] = useState({
    title: '',
    reason: 'roadworks' as const,
    description: '',
    latitude: '13.0827',
    longitude: '80.2707',
    radius: '5',
    alternativeRoute: '',
    severity: 'medium' as const,
    startTime: new Date().toISOString().slice(0, 16),
    endTime: '',
  })

  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement> | { name: string; value: string }
  ) => {
    const { name, value } = 'name' in e.target ? e.target : e
    setFormData((prev) => ({ ...prev, [name]: value }))
    setError('')
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setSuccess(false)

    try {
      const latitude = parseFloat(formData.latitude)
      const longitude = parseFloat(formData.longitude)
      const radius = parseFloat(formData.radius)

      if (isNaN(latitude) || isNaN(longitude) || isNaN(radius)) {
        setError('Latitude, Longitude, and Radius must be valid numbers')
        return
      }

      const newDiversion: Omit<Diversion, 'id' | 'createdAt' | 'updatedAt'> = {
        title: formData.title,
        reason: formData.reason,
        description: formData.description,
        location: { latitude, longitude },
        radius,
        alternativeRoute: formData.alternativeRoute,
        severity: formData.severity,
        startTime: new Date(formData.startTime).toISOString(),
        endTime: formData.endTime ? new Date(formData.endTime).toISOString() : undefined,
        createdBy: 'admin1',
      }

      await onSubmit(newDiversion)

      // Reset form
      setFormData({
        title: '',
        reason: 'roadworks',
        description: '',
        latitude: '13.0827',
        longitude: '80.2707',
        radius: '5',
        alternativeRoute: '',
        severity: 'medium',
        startTime: new Date().toISOString().slice(0, 16),
        endTime: '',
      })
      setSuccess(true)
      setTimeout(() => setSuccess(false), 3000)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create diversion')
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Add New Diversion</CardTitle>
        <CardDescription>Create a new traffic diversion alert</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="title">Title *</Label>
              <Input
                id="title"
                name="title"
                placeholder="e.g., Road Works on Main Street"
                value={formData.title}
                onChange={handleChange}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="reason">Reason *</Label>
              <Select value={formData.reason} onValueChange={(value) => handleChange({ name: 'reason', value })}>
                <SelectTrigger id="reason">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="roadworks">Road Works</SelectItem>
                  <SelectItem value="tree_fallen">Tree Fallen</SelectItem>
                  <SelectItem value="flooding">Flooding</SelectItem>
                  <SelectItem value="political">Political Issues</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              name="description"
              placeholder="Describe the diversion reason and current situation"
              value={formData.description}
              onChange={handleChange}
              rows={3}
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="latitude">Latitude *</Label>
              <Input
                id="latitude"
                name="latitude"
                type="number"
                step="0.0001"
                placeholder="13.0827"
                value={formData.latitude}
                onChange={handleChange}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="longitude">Longitude *</Label>
              <Input
                id="longitude"
                name="longitude"
                type="number"
                step="0.0001"
                placeholder="80.2707"
                value={formData.longitude}
                onChange={handleChange}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="radius">Radius (km) *</Label>
              <Input
                id="radius"
                name="radius"
                type="number"
                step="0.1"
                placeholder="5"
                value={formData.radius}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="severity">Severity *</Label>
              <Select value={formData.severity} onValueChange={(value) => handleChange({ name: 'severity', value })}>
                <SelectTrigger id="severity">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="alternativeRoute">Alternative Route</Label>
              <Input
                id="alternativeRoute"
                name="alternativeRoute"
                placeholder="e.g., Use Broadway Street"
                value={formData.alternativeRoute}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="startTime">Start Time *</Label>
              <Input
                id="startTime"
                name="startTime"
                type="datetime-local"
                value={formData.startTime}
                onChange={handleChange}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="endTime">End Time</Label>
              <Input
                id="endTime"
                name="endTime"
                type="datetime-local"
                value={formData.endTime}
                onChange={handleChange}
              />
            </div>
          </div>

          {error && <div className="rounded-md bg-red-50 p-3 text-sm text-red-600">{error}</div>}

          {success && (
            <div className="rounded-md bg-green-50 p-3 text-sm text-green-600">
              Diversion created successfully!
            </div>
          )}

          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? 'Creating...' : 'Create Diversion'}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
