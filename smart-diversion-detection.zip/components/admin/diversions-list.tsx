'use client'

import { Diversion } from '@/lib/types'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Trash2, MapPin, Clock, AlertCircle } from 'lucide-react'
import { format } from 'date-fns'

interface DiversionsListProps {
  diversions: Diversion[]
  onDelete: (id: string) => Promise<void>
  isLoading?: boolean
}

const severityColors = {
  low: 'bg-blue-100 text-blue-800',
  medium: 'bg-yellow-100 text-yellow-800',
  high: 'bg-red-100 text-red-800',
}

const reasonLabels = {
  roadworks: 'Road Works',
  tree_fallen: 'Tree Fallen',
  flooding: 'Flooding',
  political: 'Political Issues',
  other: 'Other',
}

export function DiversionsList({ diversions, onDelete, isLoading = false }: DiversionsListProps) {
  if (diversions.length === 0) {
    return (
      <Card>
        <CardContent className="pt-10">
          <div className="flex flex-col items-center justify-center space-y-3 text-center">
            <AlertCircle className="h-12 w-12 text-gray-400" />
            <div>
              <p className="text-sm font-medium text-gray-900">No diversions active</p>
              <p className="text-xs text-gray-500">Create a new diversion to get started</p>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Active Diversions</CardTitle>
        <CardDescription>Manage all traffic diversions ({diversions.length})</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {diversions.map((diversion) => (
            <div
              key={diversion.id}
              className="flex items-start justify-between rounded-lg border border-gray-200 p-4 hover:bg-gray-50"
            >
              <div className="space-y-2 flex-1">
                <div className="flex items-center gap-3">
                  <h3 className="font-semibold text-gray-900">{diversion.title}</h3>
                  <Badge className={severityColors[diversion.severity]}>
                    {diversion.severity.charAt(0).toUpperCase() + diversion.severity.slice(1)}
                  </Badge>
                  <Badge variant="outline">{reasonLabels[diversion.reason]}</Badge>
                </div>

                {diversion.description && (
                  <p className="text-sm text-gray-600">{diversion.description}</p>
                )}

                <div className="flex flex-wrap gap-4 text-xs text-gray-500">
                  <div className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    <span>
                      {diversion.location.latitude.toFixed(4)}, {diversion.location.longitude.toFixed(4)}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" />
                    <span>{diversion.radius} km radius</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    <span>{format(new Date(diversion.startTime), 'MMM dd, HH:mm')}</span>
                  </div>
                </div>

                {diversion.alternativeRoute && (
                  <div className="text-sm text-blue-600">
                    <strong>Route:</strong> {diversion.alternativeRoute}
                  </div>
                )}
              </div>

              <Button
                variant="ghost"
                size="sm"
                onClick={() => onDelete(diversion.id)}
                disabled={isLoading}
                className="ml-4"
              >
                <Trash2 className="h-4 w-4 text-red-600" />
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
