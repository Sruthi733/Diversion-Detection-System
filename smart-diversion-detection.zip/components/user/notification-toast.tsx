'use client'

import { useEffect, useState } from 'react'
import { NotificationData } from '@/lib/types'
import { X, AlertTriangle, MapPin } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface NotificationToastProps {
  notification: NotificationData
  onClose: () => void
  autoCloseDuration?: number
}

export function NotificationToast({
  notification,
  onClose,
  autoCloseDuration = 8000,
}: NotificationToastProps) {
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(false)
      onClose()
    }, autoCloseDuration)

    return () => clearTimeout(timer)
  }, [autoCloseDuration, onClose])

  if (!isVisible) return null

  return (
    <div className="pointer-events-auto animate-slide-in rounded-lg bg-white shadow-lg border-l-4 border-orange-500 p-4 overflow-hidden">
      <div className="flex items-start gap-3">
        <AlertTriangle className="h-5 w-5 text-orange-600 flex-shrink-0 mt-0.5" />

        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-gray-900 text-sm">{notification.title}</h3>
          <p className="text-xs text-gray-600 mt-1 line-clamp-2">{notification.message}</p>

          {notification.alternativeRoute && (
            <div className="mt-2 flex items-start gap-2 bg-blue-50 rounded px-2 py-1.5">
              <MapPin className="h-3 w-3 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-xs text-blue-900">
                <strong>Suggested route:</strong> {notification.alternativeRoute}
              </div>
            </div>
          )}

          <div className="mt-2 text-xs text-gray-500">
            Distance: {notification.distance.toFixed(1)} km away
          </div>
        </div>

        <button
          onClick={() => {
            setIsVisible(false)
            onClose()
          }}
          className="flex-shrink-0 text-gray-400 hover:text-gray-600 transition-colors"
        >
          <X className="h-4 w-4" />
        </button>
      </div>
    </div>
  )
}
