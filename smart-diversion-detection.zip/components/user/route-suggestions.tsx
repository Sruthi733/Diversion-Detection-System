'use client'

import { useState, useEffect } from 'react'
import { googleMapsService } from '@/lib/google-maps-service'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { RouteStep } from '@/lib/google-maps-service'
import { Navigation2, Clock, MapPin, AlertCircle, Loader } from 'lucide-react'

interface RouteSuggestionsProps {
  userLocation?: { latitude: number; longitude: number } | null
  destinationLocation?: { latitude: number; longitude: number } | null
  alternativeRoute?: string
  diversionsAhead?: number
}

export function RouteSuggestions({
  userLocation,
  destinationLocation,
  alternativeRoute,
  diversionsAhead = 0,
}: RouteSuggestionsProps) {
  const [destination, setDestination] = useState('')
  const [routes, setRoutes] = useState<any[]>([])
  const [selectedRoute, setSelectedRoute] = useState<any | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (alternativeRoute) {
      setDestination(alternativeRoute)
    }
  }, [alternativeRoute])

  const handleGetRoute = async () => {
    if (!userLocation || !destination) {
      setError('Please provide both current location and destination')
      return
    }

    setIsLoading(true)
    setError(null)

    try {
      const route = await googleMapsService.getRoute(
        userLocation,
        { lat: destinationLocation?.latitude || 13.0827, lng: destinationLocation?.longitude || 80.2707 }
      )

      if (route) {
        setRoutes([route])
        setSelectedRoute(route)
      } else {
        setError('Could not find route. Please check your destination.')
      }
    } catch (err) {
      setError('Failed to get route information')
      console.error(err)
    } finally {
      setIsLoading(false)
    }
  }

  const handleOpenInMaps = () => {
    if (!userLocation) return

    const mapsUrl = `https://www.google.com/maps/dir/${userLocation.latitude},${userLocation.longitude}/${destination}`
    window.open(mapsUrl, '_blank')
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Navigation2 className="h-5 w-5" />
          Route Suggestions
        </CardTitle>
        <CardDescription>
          {diversionsAhead > 0 ? `${diversionsAhead} diversion(s) ahead - Get alternative routes` : 'Plan your route'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Destination Input */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Destination</label>
          <div className="flex gap-2">
            <Input
              placeholder="Enter destination or use suggested route"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleGetRoute()}
            />
            <Button onClick={handleGetRoute} disabled={isLoading || !userLocation}>
              {isLoading ? <Loader className="h-4 w-4 animate-spin" /> : 'Get Route'}
            </Button>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="flex items-start gap-2 rounded-lg bg-red-50 border border-red-200 p-3">
            <AlertCircle className="h-4 w-4 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        {/* Route Information */}
        {selectedRoute && (
          <div className="space-y-3">
            <div className="rounded-lg bg-blue-50 border border-blue-200 p-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <p className="text-xs text-gray-600 uppercase">Distance</p>
                  <p className="text-lg font-semibold text-gray-900">{selectedRoute.distance}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-600 uppercase">Estimated Time</p>
                  <p className="text-lg font-semibold text-gray-900">{selectedRoute.duration}</p>
                </div>
              </div>
            </div>

            {/* Route Steps */}
            <div className="space-y-2">
              <h4 className="text-sm font-semibold text-gray-900">Directions</h4>
              <div className="max-h-64 space-y-2 overflow-y-auto">
                {selectedRoute.steps.map((step, index) => (
                  <div key={index} className="flex gap-3 rounded-lg bg-gray-50 p-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-100 text-xs font-bold text-blue-600 flex-shrink-0">
                      {index + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-gray-900">{step.instruction}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {step.distance} • {step.duration}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Open in Maps Button */}
            <Button
              onClick={handleOpenInMaps}
              className="w-full bg-blue-600 hover:bg-blue-700"
            >
              <MapPin className="mr-2 h-4 w-4" />
              Open in Google Maps
            </Button>
          </div>
        )}

        {/* Alternative Route Suggestion */}
        {alternativeRoute && !selectedRoute && (
          <div className="rounded-lg bg-amber-50 border border-amber-200 p-4">
            <div className="flex gap-3">
              <AlertCircle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold text-amber-900">Suggested Route</h4>
                <p className="text-sm text-amber-800 mt-1">{alternativeRoute}</p>
              </div>
            </div>
          </div>
        )}

        {/* No API Key Warning */}
        {!googleMapsService.isConfigured() && (
          <div className="rounded-lg bg-yellow-50 border border-yellow-200 p-3">
            <p className="text-xs text-yellow-800">
              <strong>Note:</strong> Google Maps API not configured. Directions feature limited. Add{' '}
              <code className="bg-yellow-100 px-1 rounded">NEXT_PUBLIC_GOOGLE_MAPS_API_KEY</code> to environment variables.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
