'use client'

import { useEffect, useRef, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { AlertTriangle, MapPin, Loader } from 'lucide-react'
import { Diversion } from '@/lib/types'

interface MapViewProps {
  userLocation?: { latitude: number; longitude: number } | null
  diversions: Diversion[]
  onDiversionClick?: (diversion: Diversion) => void
  height?: string
}

export function MapView({
  userLocation,
  diversions,
  onDiversionClick,
  height = 'h-96',
}: MapViewProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const [mapInstance, setMapInstance] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!mapRef.current) return

    // Initialize map
    initializeMap()
  }, [])

  useEffect(() => {
    if (!mapInstance || !userLocation) return

    // Update user location marker
    const userMarker = new (window as any).google.maps.Marker({
      position: { lat: userLocation.latitude, lng: userLocation.longitude },
      map: mapInstance,
      title: 'Your Location',
      icon: 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
    })

    // Center map on user
    mapInstance.setCenter({ lat: userLocation.latitude, lng: userLocation.longitude })

    // Add diversion markers
    diversions.forEach((diversion) => {
      const severityColor = {
        low: 'http://maps.google.com/mapfiles/ms/icons/blue-dot.png',
        medium: 'http://maps.google.com/mapfiles/ms/icons/yellow-dot.png',
        high: 'http://maps.google.com/mapfiles/ms/icons/red-dot.png',
      }

      const marker = new (window as any).google.maps.Marker({
        position: { lat: diversion.location.latitude, lng: diversion.location.longitude },
        map: mapInstance,
        title: diversion.title,
        icon: severityColor[diversion.severity],
      })

      // Add info window on click
      const infoWindow = new (window as any).google.maps.InfoWindow({
        content: `
          <div style="padding: 10px; max-width: 200px;">
            <h3 style="margin: 0 0 5px 0; font-weight: bold;">${diversion.title}</h3>
            <p style="margin: 5px 0; font-size: 12px;">${diversion.description}</p>
            <p style="margin: 5px 0; font-size: 12px;"><strong>Radius:</strong> ${diversion.radius} km</p>
            ${diversion.alternativeRoute ? `<p style="margin: 5px 0; font-size: 12px; color: blue;"><strong>Route:</strong> ${diversion.alternativeRoute}</p>` : ''}
          </div>
        `,
      })

      marker.addListener('click', () => {
        infoWindow.open(mapInstance, marker)
        onDiversionClick?.(diversion)
      })
    })
  }, [mapInstance, userLocation, diversions, onDiversionClick])

  const initializeMap = () => {
    if (typeof (window as any).google === 'undefined') {
      setError('Google Maps not loaded. Please add your Google Maps API key.')
      setIsLoading(false)
      return
    }

    try {
      const map = new (window as any).google.maps.Map(mapRef.current, {
        zoom: 14,
        center: { lat: 13.0827, lng: 80.2707 }, // Default to Chennai
        mapTypeControl: true,
        fullscreenControl: true,
        zoomControl: true,
      })

      setMapInstance(map)
      setIsLoading(false)
    } catch (err) {
      setError('Failed to initialize map')
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="h-5 w-5" />
          Map View
        </CardTitle>
        <CardDescription>See nearby diversions on the map</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="relative">
          {isLoading && (
            <div className={`absolute inset-0 flex items-center justify-center rounded-lg bg-gray-100 ${height}`}>
              <Loader className="h-8 w-8 animate-spin text-gray-400" />
            </div>
          )}

          {error && (
            <div className={`flex items-center justify-center rounded-lg bg-red-50 p-4 ${height}`}>
              <div className="flex items-center gap-3 text-sm text-red-600">
                <AlertTriangle className="h-5 w-5" />
                <p>{error}</p>
              </div>
            </div>
          )}

          <div ref={mapRef} className={`rounded-lg bg-gray-100 ${height}`} />
        </div>

        <div className="mt-4 grid gap-2 sm:grid-cols-3">
          <div className="rounded-lg bg-blue-50 p-2 text-center">
            <div className="text-xs font-semibold text-blue-900">Low Severity</div>
            <div className="text-xs text-blue-700">Blue markers</div>
          </div>
          <div className="rounded-lg bg-yellow-50 p-2 text-center">
            <div className="text-xs font-semibold text-yellow-900">Medium Severity</div>
            <div className="text-xs text-yellow-700">Yellow markers</div>
          </div>
          <div className="rounded-lg bg-red-50 p-2 text-center">
            <div className="text-xs font-semibold text-red-900">High Severity</div>
            <div className="text-xs text-red-700">Red markers</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
